-- require('packages')
-- require('keymaps')
-- require('config')
-- require('lazy').setup('plugins')
require('ben.lazy')
require('ben.core')

vim.opt.clipboard = "unnamedplus"
