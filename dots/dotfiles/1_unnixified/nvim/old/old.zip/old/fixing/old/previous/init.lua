require('packages')
require('keymaps')
require('config')
require('lazy').setup('plugins')
