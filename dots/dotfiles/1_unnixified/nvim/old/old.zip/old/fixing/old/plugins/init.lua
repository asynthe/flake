return {
  'nvim-lualine/lualine.nvim',
  'nvim-tree/nvim-tree.lua',
}
