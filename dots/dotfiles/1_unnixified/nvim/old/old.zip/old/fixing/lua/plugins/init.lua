return {
  'nvim-tree/nvim-tree.lua',
  'lervag/vimtex',

  'williamboman/mason.nvim',
  'williamboman/mason-lspconfig.nvim',
  'neovim/nvim-lspconfig',

  { 'numToStr/Comment.nvim', opts = {} },

  {
    "numToStr/Comment.nvim",
    config = function()
      require("Comment").setup()
    end
  },

  { 
    'nvim-treesitter/nvim-treesitter',
    build = ':TSUpdate',
  },


  {
    'nvim-telescope/telescope.nvim',
    dependencies = { 'nvim-lua/plenary.nvim' }
  },

  {
    'nvim-telescope/telescope-fzf-native.nvim',
    build = 'make',
  },

  { 
    'hrsh7th/nvim-cmp',
    dependencies = {
      'L3MON4D3/LuaSnip',
      'saadparwaiz1/cmp_luasnip',
      'rafamadriz/friendly-snippets',

      'hrsh7th/cmp-nvim-lsp',
    },
  },


  { 'folke/neodev.nvim', opts = {} },

  -- gruvbox theme
  { 
    'ellisonleao/gruvbox.nvim',
    -- priority = 1000,
    -- config = function()
      -- vim.cmd("colorscheme gruvbox")
    -- end
  },

  -- Lualine.nvim
  {
    'nvim-lualine/lualine.nvim',
    dependencies = {
      "nvim-tree/nvim-web-devicons"
    },
    config = function()
      require("lualine").setup({
        icons_enabled = true,
        theme = 'gruvbox',
      })
    end,
  }

  -- LSP (Language Server Protocol)
  -- Code completion, error and warning messages
  -- Highlighting and auto-refactoring.
}
