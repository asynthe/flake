require("main.options")
require("main.commands")
require("main.lazy")
require("main.remaps")
